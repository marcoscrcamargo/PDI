Arquivo zip gerado em: 04/04/2018 17:08:29 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 3 - Filtragem 1D